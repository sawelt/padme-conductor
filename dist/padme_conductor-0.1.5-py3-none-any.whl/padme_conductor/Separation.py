from enum import Enum

class Separation(Enum):
    NO_SEPARATION = "no_separation"
    STATION = "station"
    RUN = "run"